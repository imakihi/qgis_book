I am providing this shapefile, troop_ki_32654.shp and its associated files, for readers of our QGIS book for a training purpose. Therefore,  you can use these data for your personal GIS training freely. You can redistribute these data but all users need to use these data for the personal training purpose only.
I collected these monkey location data on the ground by radio telemetry and field observations but I cannot garantee the accuracy of these data. Additionally, I am not liable for any of results and their inferences from your analysis using these monkey data.
Thank you!
20130515
Hiroo Imaki
hiroo.imaki@pacificspatial.com